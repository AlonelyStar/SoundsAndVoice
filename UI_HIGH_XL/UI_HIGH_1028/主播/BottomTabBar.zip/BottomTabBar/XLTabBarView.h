//
//  XLTabBarView.h
//  PicsLikeControl
//
//  Created by lanou on 15/10/28.
//  Copyright (c) 2015年 Tu You. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface XLTabBarView : UIView

@property (nonatomic,strong) UIButton *recommendBtn; // 推荐
@property (nonatomic,strong) UIButton *musicBtn; // 音乐
@property (nonatomic,strong) UIButton *radioFMBtn; // 电台FM
@property (nonatomic,strong) UIButton *myBtn; // 我的


@end
